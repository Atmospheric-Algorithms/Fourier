#FourierExport class: exports Fourier form based on variables in Menu class.
#Subordinate class to FourierMenu
import random as Random
import math as Math
import numpy as numpy
import time as time

class FourierExport: #nominally initiates an Export Class
    def __init__(self):

        #Lists used for string comprehension
        self.charlist="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        self.varlist="ABCDEFGHIJ"
        self.numlist="0123456789"
        self.misclist="%^*()+-./"
        self.funclist=["sin","cos","tri","saw","squ","noi"]
        for a in self.varlist+"K": self.funclist.append("cf"+a)
        
        self.pi= 3.14159265359

        self.ewdir="" #working directory
        self.ename="" #name
        self.ebits=0 #bit depth in export
        self.ebytes=0 #byte depth
        self.ehz=0 #export frequency
        self.epow=0.0 #export power
        self.elen=5.0 #export len

        self.echan=1 #channels
        self.epan=0 #pan

        self.vds=[  #variable definitions
            {"var": "f(x)", "equation": "0"},
            {"var": "A", "equation": "1"},
            {"var": "B", "equation": "2"},
            {"var": "C", "equation": "3"},
            {"var": "D", "equation": "4"},
            {"var": "E", "equation": "5"},
            {"var": "F", "equation": "6"},
            {"var": "G", "equation": "7"},
            {"var": "H", "equation": "8"},
            {"var": "I", "equation": "9"},
            {"var": "J", "equation": "10"}]

        self.fds=[
            {"fun": "cfA", "points": "[[0,'0']]"},
            {"fun": "cfB", "points": "[[0,'0']]"},
            {"fun": "cfC", "points": "[[0,'0']]"},
            {"fun": "cfD", "points": "[[0,'0']]"},
            {"fun": "cfE", "points": "[[0,'0']]"},
            {"fun": "cfF", "points": "[[0,'0']]"},
            {"fun": "cfG", "points": "[[0,'0']]"},
            {"fun": "cfH", "points": "[[0,'0']]"},
            {"fun": "cfI", "points": "[[0,'0']]"},
            {"fun": "cfJ", "points": "[[0,'0']]"},
            {"fun": "cfK", "points": "[[0,'0']]"}]

        self.finalfx="finalfx" #holds the extruded final equation

    def Go(self,wd,nm,bits,hz,power,length,vard,fund): #Performs export
        #wd: Working directory, nm: name, bits: export bits, hz: Export hz,
        #power: Export power, length: length in secs, vard: variable dicts, fund: function dicts

        time0=time.time() #time0: marks time that equation build begins
        print("Exporting project...")
        self.FillClass(wd,nm,bits,hz,power,length) # Fill the export class with the relevant data

        #print("Validating and Compiling Equation...") #Fills variables dictionary, proofreads and validates vars.
        proofread=self.Proofread(vard, fund)
        if proofread=="Fail":
            print("Proofread and Compilation failed. Check your equations and try again")
            input("Press Enter to Continue.")
            return "Fail"
        time1=time.time()-time0

        #print("Solving f(x)...")        #solves f(x) for all values of x
        floatarray=numpy.array(self.SolveArray(time0))
        time2=time.time()-time0

        #print("Writing .wav file...") #Exports f(x)  to wav file
        self.WriteWav(floatarray)
        tocomp=time.time()-time0 #tocomp: reports time to complete build

        #print("DONE")
        print("Time to complete proofread: "+str(time1))
        print("Time to complete float array: "+str(time2))
        print("Actual time to complete: "+str(tocomp))

    def FillClass(self,w,n,bs,hs,p,l): #Fills the Export Class with data from FourierMenu
        #w: working directory, n: name, bs: bits, hs: hz, p: power, vs: variable dicts
        self.ewdir=w
        self.ename=n
        self.ebits=int(bs)
        self.ebytes=int(self.ebits/8)
        self.ehz=int(hs)
        self.epow=float(p)
        self.elen=float(l)

#Compilation Equations
    def Proofread(self,vd, fd): #Performs proofread
        #vd: variable dicts
        #fd: function dicts
        for a in range(len(vd)):
            self.vds[a]["equation"]=vd[a]["equation"]
        for a in range(len(fd)):
            self.fds[a]["points"]=fd[a]["points"]
            
        if self.CompileFunctions()=="Fail":#Builds Functions. If false returned, compilation failed
            print("Compilation Failed.")
            input()
            return "Fail"            
        if self.CompileEquations()=="Fail": #Builds Equations. If false returned, compilation failed
            print("Compilation Failed.")
            input()
            return "Fail"
        return (self.vds[0]["equation"])
    def CompileFunctions(self): #Compiles every function, starting with the lowest and moving up to the highest
        for i in range(len(self.fds)): #i moves backwards through the list of fundicts
            j=len(self.vds)-1-i #j: the inverse of i (this algorithm moves backwards through self.vds)

            for k in range(len(self.fds[j]["points"])): #for each point in a  function list...
                newequation=self.CompileFunction(j, k, "fds")
                if newequation=="Fail":
                    print("Error: function " + self.fds[j]["fun"] + " point " + str(j) + " failed compilation.")
                    return "Fail"
                self.fds[j]["points"][k][1]=newequation
        return self.vds[j]["equation"]
    def CompileEquations(self): #Compiles every equation, starting with the lowest and moving up to the highest
        for i in range(len(self.vds)): #i moves backwards through the list of vardicts, up the heirarchy of variables
            j=len(self.vds)-1-i #j: the inverse of i (this algorithm moves backwards through self.vds)
            newequation=self.CompileEquation(j)
            if newequation=="Fail":
                print("Error: variable " + self.vds[j]["var"] + " failed compilation.")
                return "Fail"
            self.vds[j]["equation"]=newequation
        return self.vds[j]["equation"]
    def CompileEquation(self, index):#Cleans up equations for compilation and Builds the final f(x) Equation
    #index: index of vardicts
        vf="VARIABLE" #vf: variable or function?

        fixedequation=self.vds[index]["equation"] #fixed equation: holds updated equation
        equationcheck="" #equationcheck: will be used to ensure that all functions in equation are valid equations

        try: return str(float(fixedequation))
        except:
            fixedequation
            #print("equation for var " + str(index) + " is not a float.")

        #Equation cleanup
        fixedequation=self.UpperNoSpace(fixedequation) #converts equation to all caps, removes spaces
        fixedequation=self.NoEqualSigns(fixedequation) #handles and removes equal signs
        fixedequation=self.VarHandling(fixedequation, index, vf) #handles instances of variables
        if index==0: fixedequation=self.AddSelf(fixedequation) #adds 'self' to functions
        fixedequation=self.AddPi(fixedequation) #expands out 'pi' to value of 3.141...
        fixedequation=self.ImpliedStars(fixedequation) #Adds in * signs where '*' is implied but not entered

        #Equation proofread
        equationcheck=fixedequation #equationcheck will be proofread through alteration and deletion while leaving fixedequation alone
        equationcheck=self.ParenthesesCheck(equationcheck) #Checks that '(' count and ')' count are the same
        equationcheck=self.FunKill(equationcheck) #Removes equations and parentheses
        equationcheck=self.NumKill(equationcheck) #Removes numbers and decimal points from equation
        equationcheck=self.KillSpecChars(equationcheck) #Removes special characters
        equationcheck=self.IsEmpty(equationcheck) #Checks that proofread was successful by evaluating if equationcheck is empty

        if equationcheck=="Fail":
            return "Fail" #compilation success: False
        return fixedequation
    def CompileFunction(self, index, point, prtype):#Cleans up functions for compilation
    #index: index of fundicts
    #point: point number within fundicts[index]
    #prtype: "fds": main fundicts, otherwise holds string for function

        vf="FUNCTION" #vf: variable or function
        if prtype=="fds": fixedfunction=self.fds[index]["points"][point][1] #fixed function: holds updated function
        else: fixedfunction=prtype
        functioncheck="" #functioncheck: will be used to ensure that all functions in function are valid functions

        try: return str(float(fixedfunction))
        except: print("function for function " + str(index) + " point " + str(point) + " is not a float.")

        #function cleanup
        fixedfunction=self.UpperNoSpace(fixedfunction) #converts function to all caps, removes spaces
        fixedfunction=self.NoEqualSigns(fixedfunction) #handles and removes equal signs
        fixedfunction=self.VarHandling(fixedfunction, index, vf) #handles instances of variables
        fixedfunction=self.FunHandling(fixedfunction, index, point, vf) #handles instances of custom functions
        fixedfunction=self.AddSelf(fixedfunction) #adds 'self' to functions
        fixedfunction=self.AddPi(fixedfunction) #expands out 'pi' to value of 3.141...
        fixedfunction=self.ImpliedStars(fixedfunction) #Adds in * signs where '*' is implied but not entered
        
        #function proofread
        functioncheck=fixedfunction #functioncheck will be proofread through alteration and deletion while leaving fixedfunction alone
        functioncheck=self.ParenthesesCheck(functioncheck) #Checks that '(' count and ')' count are the same
        functioncheck=self.FunKill(functioncheck) #Removes functions and parentheses
        functioncheck=self.NumKill(functioncheck) #Removes numbers and decimal points from function
        functioncheck=self.KillSpecChars(functioncheck) #Removes special characters
        functioncheck=self.IsEmpty(functioncheck) #Checks that proofread was successful by evaluating if functioncheck is empty

        if functioncheck=="Fail": return "Fail" #compilation success: False
        print(functioncheck, fixedfunction)
        return fixedfunction
    
    #Helper functions for CompileEquations
    def CharCount(self, char, strng): #Returns instances of character char in string strng.
        counter=0 #counter: counts instances of char in strng
        for i in strng:
            if i==char:
                counter += 1
        return counter

    #Equation cleanup functions
    def UpperNoSpace(self,equ): #Returns equation equ with all uppercase letters and no spaces
        if equ=="Fail": return "Fail"
        return equ.upper().replace(" ", "")
    def NoEqualSigns(self,equ):#Returns equation equ with equal signs removed,
    #throws error if more than one equal sign present
        if equ=="Fail": return "Fail"
        equalcount=self.CharCount("=",equ)
        if equalcount>1:
            print("Warning: more than one equal sign in expression!")
            print("The equation: " + equ)
            input("Press Enter to continue")
            return "Fail" #Compilation success: False
        elif equalcount==1: #returns right-hand side of equation if there is one equal sign
            return equ.split("=")[1]
        #If equalcount is zero, no action taken
        return equ
    def VarHandling(self, equ, ind, vf): #Handles vars, returns refined equ
        #equ: equation string to be analyzed
        #ind: endex of var/fun being analyzed
        #vf: is this being performed for a VARIABLE or FUNCTION?
        #Finds all instances of VAR( in equation
        if equ=="Fail": return "Fail"
        
        varequation=str(equ) #varequation: will have vars removed one at a time
        while(varequation.find('VAR('))!=-1:
            startchar=varequation.find('VAR(')
            
            #first, var needs to follow the heirarchy order. index=0=f(x), can accept all vars
            #this check is skipped if varhandling is done by function
            if(self.varlist.find(varequation[startchar+4])+1<=ind) and vf=="VARIABLE":
                print("found var: ",self.varlist.find(varequation[startchar+4]))
                print("index: ",ind)
                print("Error: variable cannot self-reference or reference a variable higher in the heirarchy.")
                print("Variable " + self.vds[ind]["var"] + " referenced variable " + varequation[startchar+4] + "!")
                return "Fail" #Compilation success: False
            
            #Make sure that one character is the only thing in variable parentheses
            if(varequation[startchar+5] != ")"):
                print("Error: only one character allowed in VAR() function!")
                return "Fail" #Compilation success: False
            
            varequation=varequation[varequation.find('VAR(')+3:] #chops off varequation after first found 'VAR(' instance.
            
        #Expand out all vars 
        for i in range(len(self.varlist)):
            findvalue="VAR(" + self.varlist[i] + ")" #Findvalue: iterates through all valid var values
            replacevalue = "(" + str(self.vds[i+1]["equation"]) + ")" #Replacevalue, the equation for the var in parentheses
            equ=str(equ).replace(findvalue, replacevalue)
        return equ
    def FunHandling(self, equ, ind, pt, vf): #Handles functions, returns refined equ
        #equ: equation string to be analyzed
        #ind: endex of var/fun being analyzed
        #pt: point index in function
        #vf: is this being performed for a VARIABLE or FUNCTION?
        #Finds all instances of VAR( in equation
        if equ=="Fail": return "Fail"
        
        funequation=equ #funequation: will have funs removed one at a time
        while(self.SearchCusFuns(equ))!=-1:
            startchar=self.SearchCusFuns(equ)
            
            #first, fun needs to follow the heirarchy order. 
            #this check is skipped if funhandling is done by a VARIABLE
            if((self.varlist+"K").find(funequation[startchar+2])+1<=ind) and vf=="FUNCTION":
                print("Error: function cannot self-reference or reference a function higher in the heirarchy.")
                print("function " + self.fds[ind]["fun"] + " " + str(self.fds[ind]["points"][pt]) + " referenced function " + funequation[startchar+2] + "!")
                return "Fail" #Compilation success: False
    
            funequation=funequation[funequation.find('CF')+3:] #chops off funequation after first found 'CF[A-K](' instance.
            #No expansion of functions, they are resolved during the Solve function
        return equ
    def SearchCusFuns(self,strng): #checks string strng for instances of cf[A-K](
        #returns start index if found, -1 if nothing found
        findindex=-1 #findindex: index of start character in strng of custom function call
        for a in self.fds:
            findindex=strng.find(a["fun"]+'(')
            if findindex!=-1:
                return findindex
        return -1  
    def AddSelf(self, equ):# returns equ with self added in front of all equations
        if equ=="Fail": return "Fail"
        for f in self.funclist:
            equ= str(equ).replace(f.upper(), "self."+f.upper())
        equ=str(equ).replace('self.self.', 'self.')
        return equ
        
    def AddPi(self, equ): #Returns string equ with value of pi substituted for 'pi'
        if equ=="Fail": return "Fail"
        return str(equ).replace("PI", "3.14159265359")
    def ImpliedStars(self,equ): #Adds '*' where * signs are implied but not added
        if equ=="Fail": return "Fail"
        for i in range(len(equ)-1): #iterate to second to last character in equ
            if ((equ[i] in self.numlist) and (equ[i+1] in self.charlist)): #looks for a number followed by a character, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i]=='s') and (equ[i+1] in self.charlist)): #looks for a number followed by self..., which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i] in self.charlist) and (equ[i+1] in self.numlist)): #looks for a character followed by a mumber, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i] in self.numlist) and (equ[i+1]=="(")): #looks for a number followed by parentheses, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i]=="X") and (equ[i+1]=="(")): #looks for X followed by parentheses, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i+1] in self.numlist) and (equ[i]==")")): #looks for parentheses followed by a number, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i+1] == "X") and (equ[i]==")")): #looks for parentheses followed by X, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
            if ((equ[i+1] == "s") and (equ[i]==")")): #looks for parentheses followed by s, which implies a *.
                equ=equ[:i+1]+"*"+equ[i+1:]
        return equ
    #Equation proofread functions
    def ParenthesesCheck(self, equ): #Check that '(' count and ')' count are equal.
        if equ=="Fail": return "Fail"
        if self.CharCount("(",equ) != self.CharCount(")",equ):
            print("Warning: parentheses counts don't match for equation!")
            input("Press enter to continue")
            return "Fail" #Compilation success: False
        return equ
    def FunKill(self, equ): #Removes functions and parentheses
        if equ=="Fail": return "Fail"
        #Remove all functions
        for s in self.funclist:
            equ=equ.replace("self."+s.upper(),"") #for removing functions in f(x)
            equ=equ.replace(s.upper(),"") #for removing functions not in f(x)
        #Remove all parentheses
        return equ.replace("(","").replace(")","")
    def NumKill(self, equ): #Removes numbers and decimal points in numbers
        if equ=="Fail": return "Fail"
        numless=self.NumStartSearch(equ) #numless: has numbers removed from it until there are no numbers left
        #NumStartSearch: accounts for removing numbers with decimals.
        #This block removes runs of numbers one at a time until none are left
        while(equ!=numless):
            if numless=="Fail": return "Fail" #Compilation success: False, NumStartSearch or NumEndSearch failed
            equ=str(numless)
            numless=self.NumStartSearch(equ)
            if numless==None:
                numless=""
            if equ==None:
                equ=""
        return equ
    #Helper functions for function NumKill
    def NumStartSearch(self,strng): #Searches string for number/decimal,
        if strng=="Fail": return "Fail"
        #strng: string to be searched for numbers
        decyet=False #decyet: has a decimal been encountered yet?
        numstart=-1 #index where found number starts
        numend=-1 #index where found number ends
        for i in range(len(str(strng))):
            if (strng[i]=="."):
                decyet==True
            if (strng[i] in self.numlist) or (strng[i]=="."):
                numstart=i
                numend=self.NumEndSearch(strng,i+1,decyet)
                if numend==False: return "Fail" #Compilation success: False
                return strng[:numstart]+strng[numend:]
        return strng      
    def NumEndSearch(self, strng, ind, decyet):  #finds end of number
        #strng: a string (equation)
        #ind: index of string str where a number begins
        #decyet: True/False, has a decimal point been encountered yet?
        if len(strng)==ind: return ind #covers case of number going to end of equation
        if strng[ind]==".":
            if decyet==True:
                print("Error: number has double decimals, invalid!")
                input("Press Enter to Continue")
                return "Fail" #Compilation success: False
            decyet=True
        if (strng[ind]==".") or (strng[ind] in self.numlist):
            return self.NumEndSearch(strng,ind+1,decyet) #function recursive, recurses until number end found
        else:
            return ind
    def KillSpecChars(self, equ): #Removes X and mathematical characters
        if equ=="Fail": return "Fail"
        equ=str(equ).replace("X","") #Remove all Xs
        for c in self.misclist: equ=equ.replace(c,"") #Remove all misc symbols
        return equ
    def IsEmpty(self, equ): #Checks that equ is empty string
        if equ=="Fail": return "Fail"
        if equ=="None": return True
        if len(str(equ))!=0:
            print("Error: additional unidentified symbols in equation!")
            print("Unidentified symbols: " + str(equ))
            return "Fail"

#Solve Functions
    #Helper equations for SolveArray
    def SolveArray(self, t0): #Solve array for export
        #t0: time function started
        floarray=numpy.zeros(int(float(self.elen)*self.ehz)) #floarray: float values of solved equation
        maxvalue=1.0 #maxvalue: highest amplitude value

        for i in range(len(floarray)):
            if i==10000:
                time1=time.time()
                elapsed=time1-t0
                tocomp=len(floarray)/10000*elapsed/0.85 #tocomp: estimated time to complete export
                #extrapolates 10000 solves to length of full array, and allows for 15% of time for file writing
                print("Estimated time to complete export: "+str(tocomp))
                
            j=float(i)/float(self.ehz)
            floarray[i]=self.Solve(j) #generate array of values for equation
            if abs(floarray[i])>maxvalue: maxvalue=abs(floarray[i]) #searches for highest amplitude signal in equation

        rangeconv=(2**(self.ebits-1)+1) #maximum value for conversion for bits
        adjustval=rangeconv*self.epow/maxvalue*0.99 #value by which to adjust floarray
        
        return floarray*adjustval #Normalizes floarray vals to maximum amplitude value, relative power option,
        #and converts to a format that can be read as bytes

    def Solve(self, X): #Solve equation for X=time in secs
        return eval(self.vds[0]["equation"])

    def SIN(self,X): #solves sin function
        return Math.sin(X) 

    def COS(self,X): #solves cosine function
        return Math.cos(X)

    def TRI(self,X): #solves tri function
        x1=(X%(2.0*self.pi))/(2.0*self.pi) #converts x to fraction of a revolution
        if (x1<=0.25): return 4.0*x1
        if (x1<=0.75): return 1.0-(4.0*(x1-0.25))
        return -1.0+4.0*(x1-0.75)

    def SQU(self,X): #solves square function
        x1=(X%(2.0*self.pi))/(2.0*self.pi) #converts x to fraction of a revolution
        if (x1<0.5): return 1,0
        return -1.0

    def SAW(self,X): #solves saw function
        x1=(X%(2.0*self.pi))/(2.0*self.pi) #converts x to fraction of a revolution
        if (x1<0.5): return 2.0*x1
        return -1.0+2.0*(x1-0.5)

    def NOI(self,X): #solves noise function
        return (Random.random()*2)-1
    def NOI(self): #solves NOI function, X pass is optional
        return (Random.random()*2)-1
        
    def CFA(self,X): return self.CF(0,X)
    def CFB(self,X): return self.CF(1,X)
    def CFC(self,X): return self.CF(2,X)
    def CFD(self,X): return self.CF(3,X)
    def CFE(self,X): return self.CF(4,X)
    def CFF(self,X): return self.CF(5,X)
    def CFG(self,X): return self.CF(6,X)
    def CFH(self,X): return self.CF(7,X)
    def CFI(self,X): return self.CF(8,X)
    def CFJ(self,X): return self.CF(9,X)
    def CFK(self,X): return self.CF(10,X)
    def CF(self,ind,X): #solves custom function
        X=float(X % self.fds[ind]["points"][-1][0])
        if len(self.fds[ind]["fun"])==1: return self.fds[ind]["fun"][0][1] #special case for just one point
        firstpoint=0 #firstpoint: pointlist point before time X
        lastpoint=0 #lastpoint: pointlist point after time X 
        for a in range(len(self.fds[ind]["points"])): #searches for first point to equal or exceed X
            if self.fds[ind]["points"][a][0]==X: #if x equals a point, return the value of that point
                return eval(self.fds[ind]["points"][a][1])
            if self.fds[ind]["points"][a][0]>X: #if a point exceeds x, 
                firstpoint=a-1
                lastpoint=a
                break
                
        firstt=float(self.fds[ind]["points"][firstpoint][0]) #first t: time of firstpoint
        lastt=float(self.fds[ind]["points"][lastpoint][0]) #lastt: time of lastpoint
        ratio=(X-firstt)/(lastt-firstt) #ratio: decimal value 0-1, distance traveled between firstpoint and lastpoint
        return (1-ratio)*eval(self.fds[ind]["points"][firstpoint][1]) + ratio*eval(self.fds[ind]["points"][lastpoint][1])
        
    #Helper functions for WriteWav
    def WriteWav(self, exparray): #writes wav file from exparray
        #exparray
        
        #compute variables to generate .wav header
        byterate=self.ehz*self.echan*self.ebytes #bytes per second
        subchunk2size=self.ehz*self.ebytes*self.echan*self.elen #size of subchunk w must be in header, but is variabel. subchunk 1 size is always the same.
        chunksize=36+subchunk2size #chunksize: sum chunk1 chunk2

        #Header compiles all of the info for a wav header
        header=[82, 73, 70, 70, chunksize%256, (chunksize/256)%256, (chunksize/65536)%256, chunksize/16777216,
                87, 65, 86, 69, 102, 109, 116, 32, 16, 0, 0, 0, 1, 0, self.echan%256, self.echan/256, self.ehz%256,
                (self.ehz/256)%256, (self.ehz/65536)%256, self.ehz/16777216, byterate%256, (byterate/256)%256, (byterate/65536)%256,
                byterate/16777216,(self.echan*self.ebytes)%256, (self.echan*self.ebytes)/256, int(self.ebits)%256,
                int(self.ebits)/256, 100, 97, 116, 97, subchunk2size%256, (subchunk2size/256)%256, (subchunk2size/65536)%256, subchunk2size/16777216]
        headernp=numpy.array(header) #holds header in numpy array
        #Creates array of float values
        
        #Prep wav write file
        writefilepath=self.ewdir +"\Exports\\" + self.ename + "_Export.wav"
        writefile=open(writefilepath, "wb")

        
        #Writes header 
        for x in headernp: writefile.write(bytearray([int(x)]))
        #Writes array
        for x in exparray:
            #Writes each value in little endian style
            i=int(x)

            #If bytes=1, values need a 2s complement inversion. I don't know why this is only needed if bytes=1, but don't mess with this.
            if self.ebytes==1:
                if i<128:
                    writefile.write(bytearray([int((i+128)%256)]))
                else:
                    writefile.write(bytearray([int((i-128)%256)]))
            else:
                for y in range(self.ebytes):
                    writefile.write(bytearray([int((i/(256**y))%256)]))
                    
        writefile.close()
        print("File written to ")
        print(writefilepath)
        return True

        
        
        
                
            
        
        

    
