#FourierExport: Export Class for Fourier
#Fourier: Make a sound based off of an equation.

import sys
import os
import ast
import webbrowser

import FourierExport as FourierExport
import NameMaker as Namemaker

class FourierMenu:
#Initialization funcs    
    def __init__(self): #Initiates the program

        self.wd=os.path.dirname(os.path.abspath(__file__)) #self.wd: working directory
        self.version="v0.4" #Fourier version number
        self.saveversion=self.version #Save file Fourier version number

        #Project variables
        self.name="NOTSET" #Project name
        self.defaultfx="NOTSET" #Main default function
        self.exportbits=11111 #export bit depth
        self.exporthz=11111 #export sampling frequency
        self.exportpow=0.0000 #max amplitude of export
        self.exportlen=0.0000 #length in secs of export

        #Keeps Track of Default Variables
        self.dname="NOTSET" 
        self.ddefaultfx="NOTSET" #default defaultfx setting
        self.dexportbits=11111 #default exportbits
        self.dexporthz=11111 #default exporthz
        self.dexportpow=0.0000 #default exportpow
        self.dexportlen=0.0000 #default exportlen

        self.LoadDefaults()
        self.FE=FourierExport.FourierExport()
        
        #Variables will be held in the var dictionary
        self.vardicts=[
            {"var": "f(x)", "equation": self.defaultfx},
            {"var": "A", "equation": "1"},
            {"var": "B", "equation": "1"},
            {"var": "C", "equation": "1"},
            {"var": "D", "equation": "1"},
            {"var": "E", "equation": "1"},
            {"var": "F", "equation": "1"},
            {"var": "G", "equation": "1"},
            {"var": "H", "equation": "1"},
            {"var": "I", "equation": "1"},
            {"var": "J", "equation": "1"}]

        self.fundicts=[
            {"fun": "cfA", "points": [[0,'1']]},
            {"fun": "cfB", "points": [[0,'1']]},
            {"fun": "cfC", "points": [[0,'1']]},
            {"fun": "cfD", "points": [[0,'1']]},
            {"fun": "cfE", "points": [[0,'1']]},
            {"fun": "cfF", "points": [[0,'1']]},
            {"fun": "cfG", "points": [[0,'1']]},
            {"fun": "cfH", "points": [[0,'1']]},
            {"fun": "cfI", "points": [[0,'1']]},
            {"fun": "cfJ", "points": [[0,'1']]},
            {"fun": "cfK", "points": [[0,'1']]}]

        self.writelist=("self.name","self.saveversion","self.exportbits","self.exporthz","self.exportpow",
                        "self.exportlen","self.vardicts","self.fundicts") #self.writelist: list of variables to Save/Load
        
        self.varlist=("f(x)","A","B","C","D","E","F","G","H","I","J") #self.varlist: list of variables
        
        print("\n\nFourier \n\nCompile an equation into a sound!")
        print(self.version)
        self.MainMenu()

    def LoadDefaults(self): #Loads Defaults from Defaults file into Fourier Project
        #creates folder structure for the defaults
        if os.path.isdir(self.wd + "//Defaults")==False: #Makes directory if it doesn't exist
            os.mkdir(self.wd + "//Defaults")
        defaultdir=self.wd + "//Defaults//Defaults.fod" #defaultdir: directory for default file
        
        if os.path.isfile(defaultdir)==False:  #If no default file, constructs default default file
            defaultfilew=open(defaultdir, "w") #defaultfilw w: defaults file, for writing
            defaultfilew.write("self.name:!Random\n")
            defaultfilew.write("self.defaultfx:sin(2 * pi * 440 * x)\n")
            defaultfilew.write("self.exportbits:16\n")
            defaultfilew.write("self.exporthz:44100\n")
            defaultfilew.write("self.exportpow:1.0\n")
            defaultfilew.write("self.exportlen:5.0\n")
            defaultfilew.close()
            
        defaultfiler=open(defaultdir, "r") #Loads defaults file. defaultfiler: fefault file for reading.
        defloadlines=defaultfiler.readlines() #Holds lines for default file
        for a in defloadlines:
            asplit=a.replace('\n','').split(":")
            if asplit[0]=="self.name":
                self.dname=asplit[1]
                if self.name.upper()=="!RANDOM":
                    self.name=Namemaker.MakeName()
            elif asplit[0]=="self.defaultfx": self.ddefaultfx=asplit[1]
            elif asplit[0]=="self.exportbits": self.dexportbits=int(asplit[1])
            elif asplit[0]=="self.exporthz": self.dexporthz=int(asplit[1])
            elif asplit[0]=="self.exportpow": self.dexportpow=float(asplit[1])
            elif asplit[0]=="self.exportlen": self.dexportlen=float(asplit[1])
            else:
                asplit[1]
        defaultfiler.close()

        #Loading project data from defaults
        self.name=self.dname
        if self.dname.upper()=="!RANDOM":
            self.name=Namemaker.MakeName()
        self.defaultfx=self.ddefaultfx
        self.exportbits=self.dexportbits
        self.exporthz=self.dexporthz
        self.exportpow=self.dexportpow
        self.exportlen=self.dexportlen
        
            
        
#Main Menu funcs
    def MainMenu(self): #Main Menu
        while True:
            print("\nProject "+self.name)
            print(('Main Menu:\n'
                   '1:Enter Equation\n'
                   '2:Set Variables (Vars)\n'
                   '3:Set Custom Functions \n'
                   '4:Export Options\n'
                   '5:Export\n'
                   '6:List All Variables\n'
                   '7:Save Project\n'
                   '8:Load Project\n'
                   '9:Help\n'
                   '10:Exit\n'))
            command=input()
            if command=="1": self.vardicts[0]["equation"]=self.EquationMenu(self.vardicts[0]["var"])
            elif command=="2": self.SetVar("None","None")
            elif command=="3": self.SetFun("None","None")
            elif command=="4": self.ExportMenu()
            elif command=="5": self.Export()
            elif command=="6": self.Debug()
            elif command=="7": self.Save()
            elif command=="8": self.LoadMenu()
            elif command=="9": self.Help()
            elif command=="10": #Exit
                if self.YouSure()==True:
                    print("Goodbye!")
                    print("Press Enter to Exit")
                    input()
                    return
            else:
                print("Error, invalid command")
#(1)Equation entry
    def EquationMenu(self, thevar): #Returns the equation for variable thevar
        #thevar: variable (f(x), A, B, etc) that the equation will define
        #thevar can also represent a point in a function in the form of cf[A-K][Number]
        vf="?" #vf: identifies equation as VARIABLE or FUNCTION
        currentequation="?" #currentequation: holds equation before being set via EquationMenu    

        #Figures out if thevar describes a function or a variable, then retrieves the corresponding expression
        index=self.FindVarIndex(thevar) #looks for thevar name in varlist
        if index=="Not found":
            index=self.FindFunIndex(thevar[0:3])
            if index=="Not found":
                print("Something went wrong, the variable/function index was not found!")
                input("Press Enter to continue...")
                return False
            else:
                vf="FUNCTION"
                listpoint=int(thevar[3:]) #listpoint: the point index in the points list in custom functions
                currentequation=self.fundicts[index] #fundicts / specific func / points list / point number in thevar / equation.
        else:
            vf="VARIABLE"
            currentequation=self.vardicts[index]["equation"] #currentequation: equation value

        #Enter the value for the equation
        while True:
            print(('\nEquation Entry Menu. '
                   'Values allowed: \n'
                   'X: time in seconds.\n'
                   'pi:3.14159265359.\n'
                   'var(A to J): can be used for variables.\n'
                   'sin(): sine wave.\n'
                   'cos(): cosine wave.\n'
                   'tri(): triangle wave (starts at zero).\n'
                   'saw(): saw  wave (starts at zero).\n'
                   'squ(): square wave (starts at 1).\n'
                   'noi(): noise.\n'
                   'cfA() to cfK(): can be used to create custom functions.\n'
                   'BACK: exit without overwriting last equation.\n'
                   'Write your equation.\n'
                   'Current equation: '), thevar, "=", currentequation)
            
            equationholder=input(str(thevar + "=")) #equationholder: holds equation within this function
            if (equationholder=="BACK") and (vf=="VARIABLE"): return currentequation
            if (equationholder=="BACK") and (vf=="FUNCTION"): return "BACK"

            #checks new equation for validity
            if vf=="VARIABLE":
                simvd=self.vardicts
                simvd[self.FindVarIndex(thevar)]["equation"]=equationholder
                if(self.FE.Proofread(simvd, self.fundicts)=="Fail"): #proofreads new equation
                    print("Error: equation compilation failed.")
                else:
                    return equationholder
            return equationholder

#(2)Variable building funcs        
    def SetVar(self, haveavar, haveavalue): #Set value of variable
        okletters="ABCDEFGHIJ" #list of acceptable var letters
        var="" #var will hold name of variable to define with the equation
        equation="" #equation will hold the equation 
        
        if (haveavar != "None"): #option if variable is indicated for this function
            var=haveavar
        else: #if variable not indicated, prompts for var to set
            while True:
                print("Enter a variable from A to J")
                command=input()
                try:
                    if (command.upper() in okletters and len(command)==1):
                        var=command.upper()
                        break
                    else:
                        print("Error, choose a character between A and J")
                except:
                    print("Error, choose a character between A and J")
                    
        if (haveavalue != "None"): #option if equation is indicated for this function
            equation=haveavalue
            
        #if equation not indicated, prompts for equation to be set
        equation=self.EquationMenu(var)
        self.vardicts[self.FindVarIndex(var)]["equation"]=equation
    def FindVarIndex(self, varname): #returns index of var with name varname
        for x in range(len(self.vardicts)):
            if self.vardicts[x]["var"]==varname:
                return x
        return "Not found"

#(3)Function building funcs
    def SetFun(self, haveafun, haveavalue): #Sets value of function
        okletters="ABCDEFGHIJK" #list of acceptable var letters
        fun="" #var will hold name of variable to define with the equation
        equation=[] #equation will hold the equation 
        
        if (haveafun != "None"): #option if function is indicated for this function
            fun=haveafun
        else: #if function not indicated, prompts for fun to set
            while True: #Chooses function to fill
                print("\nEnter a function from A to K")
                command=input()
                try:
                    if (command.upper() in (okletters+"K") and len(command)==1):
                        fun=command.upper()
                        break
                    else:
                        print("Error, choose a character between A and J")
                except:
                    print("Error, choose a character between A and J")
                    
        if (haveavalue != "None"): #option if equation is indicated for this function
            equation=haveavalue
            
        #if equation not indicated, prompts for equation to be set
        ind=int(self.FindFunIndex("cf"+fun)) #ind: index of function to set
        points=self.FunctionBuilder(ind) #points: hold points from functionbuilder 
        if points=="BACK": return "BACK"
        self.fundicts[ind]["points"]=points
    def FindFunIndex(self, funname): #returns index of fun with name funname
        for x in range(len(self.fundicts)):
            if self.fundicts[x]["fun"]==funname:
                return x
        return "Not found"
    def FunctionBuilder(self, ind): #builds function
        pointholder=[] #will be used to hold points
        pointholderhold=[] #tests new additions before confirmation in pointholder
        t=0.0
        v=1.0
        okchars=(" +-/%*")
        print("\nFunction Builder Menu")
        print("For Custom Function "+self.fundicts[ind]["fun"])
        print("Current value for Custom Function:")
        for a in self.fundicts[ind]["points"]:
            print ("Time: "+str(a[0])+"   Value: "+str(a[1]))

        print("\nPoint one (time value must be zero)")

        while True: #Enters next point
            while True: #enters a time point
                if len(pointholder)==0: #Sets t to zero if filling first point
                    print("First point's time value is always zero.")
                    input("Press Enter to continue.")
                    t=0.0
                    break
                print("")
                for a in self.fundicts[ind]["points"]: #Sets time t in all other cases
                    print ("Time: "+str(a[0])+"   Value: "+str(a[1]))
                print("\nEnter time for next point,")
                print("Or CANCEL to cancel entry,")
                print("Or DONE to complete function.")
                t=input()
                if t.upper()=="CANCEL": return "BACK"
                if t.upper()=="DONE": return pointholder
                try:
                    t=float(t)
                    if t<=pointholder[-1][0]:
                        print("Error, time point must be greater than previous time point")
                    else:
                        break        
                except: print("Error, enter a number.")
            while True: #enters point value
                v=self.EquationMenu(self.fundicts[ind]["fun"]+str(len(pointholder)+1))
                if v=="BACK": return "BACK"
                pointholderhold.append([t,v])
                #proofreads point
                simfd=self.fundicts
                simfd[ind]["points"]=pointholderhold
                if self.FE.CompileFunction(ind, len(pointholderhold)-1, v)!="Fail": 
                    break
                #If compilation failed...
                print("Error, enter a valid point")
                pointholderhold.pop()
            pointholder=pointholderhold

        return pointholder
    
#(4)Export Settings
    def ExportMenu(self): #Set options for Export
        while True:
            print(('\nExport Options Menu:'
                   '\n1:Set Name, currently '), self.name,
                   '\n2:Set Export bytes, currently ', int(self.exportbits/8),
                   '\n3:Set Export Hz, currently ', self.exporthz,
                   '\n4:Set Export Power, currently ', self.exportpow,
                   '\n5:Set Export Length (seconds), currently ', self.exportlen,
                   '\n6:Set Defaults',
                   '\n7:Back to Main Menu')
            command=input()
            if(command=="1"):
                self.name=self.SetName("None")
            elif(command=="2"):
                self.exportbits=self.SetExportBits("None")
                return
            elif (command=="3"):
                self.exportHz=self.SetExportHz("None")
                return
            elif (command=="4"):
                self.exportpower=self.SetExportPower("None")
                return
            elif(command=="5"):
                self.exportlen=self.SetExportLen("None")
                return
            elif(command=="6"):
                self.DefaultsMenu()
            elif(command=="7"):
                return
            else:
                print("Error, invalid command.")
    #(4)(1)
    def SetName(self, haveavar): #Sets the name
        if haveavar!="None": return haveavar
        print("Set a project name, currently ", self.name)
        print("Type '!RANDOM' to generate a random name")
        print("Type BACK to keep old name")
        command=input()
        if command.upper()=="!RANDOM":
            return Namemaker.MakeName()
        if command.upper()=="BACK":
            return self.name
        return command
    #(4)(2)
    def SetExportBits(self, haveavalue): #set bit depth for sound export
        if haveavalue=="None":
            while True:
                print("Set value for export bytes. Currently: ", str(self.exportbits/8))
                command=input()
                try:
                    command=int(command)
                    if command>0:
                        return command*8
                except:
                    print("Error, invalid input. Export Bytes should be an integer.")
        return haveavalue
    #(4)(3)
    def SetExportHz(self, haveavalue): #set sampling frequency for sound export
        if haveavalue=="None":
            while True:
                print("Set value for export Hz. Currently: ", self.exporthz)
                command=input()
                try:
                    return int(command)
                except:
                    print("Error, invalid input. Export Bits should be an integer.")
        return haveavalue
    #(4)(4)
    def SetExportPower(self, haveavalue): #set max amplitude for sound export
        if (haveavalue!="None"):
            return haveavalue
        while True:
            print("Set value for export Power (-1.0 to 1.0). Currently: ", self.exportpow)
            command=input()
            try: command=float(command)
            except: print("Error, invalid input. Export Power should be between -1.0 and 1.0.")
            else:
                if (command>=-1.0 and command<=1.0):
                    return command
                print("Error, invalid input. Export Power should be between -1.0 and 1.0.")
    #(4)(5)
    def SetExportLen(self, haveavalue): #set sampling frequency for sound export
        if haveavalue=="None":
            while True:
                print("Set value for export Len. Currently: ", self.exportlen)
                command=input()
                try:
                    if float(command)<0:
                        print("Error, invalid input. Export length needs to be >=0")
                    else:
                        return float(command)
                except:
                    print("Error, invalid input. Export Length should be a float.")
        return haveavalue
    #(4)(5)
    def DefaultsMenu(self): #Set defaults
        while True:
            print(('\nDefault Export Options Menu:'
                   '\n1:Set Default Name, currently '), self.dname,
                   '\n2:Set Default Export Bytes, currently ', int(self.dexportbits/8),
                   '\n3:Set Default Export Hz, currently ', self.dexporthz,
                   '\n4:Set Default Export Power, currently ', self.dexportpow,
                   '\n5:Set Default Export Length (seconds), currently ', self.dexportlen,
                   '\n6:Restore Original Defaults',
                   '\n7:Back to Main Menu')
            command=input()
            if(command=="1"):
                self.dname=self.SetName("None")
            elif(command=="2"):
                self.dexportbits=self.SetExportBits("None")
                return
            elif (command=="3"):
                self.dexporthz=self.SetExportHz("None")
                return
            elif (command=="4"):
                self.dexportpow=self.SetExportPower("None")
                return
            elif(command=="5"):
                self.dexportlenself.SetExportLen("None")
                return
            elif(command=="6"):
                self.OriginalDefaults()
            elif(command=="7"):
                return
            else:
                print("Error, invalid command.")
            self.SaveDefaults()

    def OriginalDefaults(self): #Restores original defaults
        self.dname="!Random"
        self.dexportbits=16
        self.dexporthz=44100
        self.dexportpow=1.0
        self.dexportlen=5.0
    def SaveDefaults(self): #Saves new settings to default file
        defaultdir=self.wd + "//Defaults//Defaults.fod" #defaultdir: directory for default file
        defaultfilew=open(defaultdir, "w") #defaultfilw w: defaults file, for writing
        defaultfilew.write("self.name:"+self.dname+"\n")
        defaultfilew.write("self.defaultfx:"+self.ddefaultfx+"\n")
        defaultfilew.write("self.exportbits:"+str(self.dexportbits)+"\n")
        defaultfilew.write("self.exporthz:"+str(self.dexporthz)+"\n")
        defaultfilew.write("self.exportpow:"+str(self.dexportpow)+"\n")
        defaultfilew.write("self.exportlen:"+str(self.dexportlen)+"n")
        defaultfilew.close()

#(5)Export function (mostly handled by FourierExport class).
    def Export(self): #Export an equation
        if os.path.isdir(self.wd + "//Exports")==False:
            os.mkdir(self.wd + "//Exports")
        while True:
            print("Export Menu")
            print(("1: Standard Export\n"
                  "2: Multi-Export: Manual\n"
                  "3: Multi-Export: Octaves\n"
                  "4: Back"))
            command=input()
            if command=="1":
                self.FE.Go(self.wd,self.name,self.exportbits,self.exporthz,self.exportpow, self.exportlen, self.vardicts, self.fundicts)
                return
            elif command=="2":
                self.ManualExport()
                return
            elif command=="3":
                self.OctavesExport()
                return
            elif command=="4": return
            else:
                print("Invalid command.")
        return
    def ManualExport(self): #Exports a list of points
        thevar="Z" #thevar: chosen variable to use for multi-export
        vallist=[] #vallist: list of values to plug into variable for export
        
        print("Manual Export List")
        while True: #input variable to vary
            print("Choose variable (A-K) that will vary for multi-export")
            command=input()
            if (command in self.varlist) and (command!="f(x)"):
                thevar=str(command)
                break
            print("Error: invalid command.")
        print("Variable chosen: "+thevar)
        varindex=self.FindVarIndex(thevar) #varindex: index of variable thevar
        oldvarval=self.vardicts[varindex]["equation"] #oldvarval: holds original var value to restore if export cancelled
        while True: #define list of values for variable thevar for multiple exports
            if len(vallist)!=0:
                print("Current points:")
                for a in vallist: print(a)
            print("Define points for export.")
            print("Enter 'DONE' to complete")
            print("Enter 'BACK' to cancel")
            command=input()
            if command.upper()=="BACK": #Back:
                self.vardicts[varindex]["equation"]=oldvarval
                return
            elif command.upper()=="DONE": #Finish export list and perform multi-export
                if len(vallist)==0:
                    print("You have to enter at least one point first!")
                else:
                    for a in range(len(vallist)): #exports each value of a
                        self.vardicts[varindex]["equation"]=vallist[a]
                        print("Exporting for "+thevar+" value " + vallist[a])
                        exportname=self.name+"_"+str(a+1) #export name: name for export file
                        self.FE.Go(self.wd,exportname,self.exportbits,self.exporthz,self.exportpow, self.exportlen, self.vardicts, self.fundicts)
                    return
            else: #A normal equation or value entered
                self.vardicts[varindex]["equation"]=command
                if self.FE.CompileEquation(varindex)!=False: #successfully compilable equation gets added to vallist
                    vallist.append(command)
                else:
                    print("Error: invalid equation.")
    def OctavesExport(self): #export series of musical notes

        twelverttwo=2.0**(1.0/12.0) #twelfth root of 2
        
        numberofnotes=0 #numberofnotes: number of notes to export
        thevar="Z" #thevar: chosen variable to use for multi-export
        startingnote=0 #startingnote: first note of export: 0=A
        theoctave=0 #theoctave: chooses a starting octave
        notelist=("A", "A-sharp/B-flat", "B", "C", "C-sharp/D-flat", "D", "D-sharp/E-flat", "E", "F", "F-sharp/G-flat",
                  "G", "G-sharp/A-flat")
        shortnotelist=("A","Bb","B","C","Db","D","Eb","E","F","Gb","G","Ab")
        octavelist=("Subsonic Bass", "Contrabass", "Bass", "Baritone", "Tenor", "Contralto", "Alto", "Mezzo Soprano",
                    "Soprano", "Sopranissimo", "Supersonic Soprano")
        
        print("Octaves Export")
        while True: #input variable to vary
            print("Choose variable (A-K) that will vary for multi-export")
            command=input()
            if (command in self.varlist) and (command!="f(x)"):
                thevar=str(command)
                break
            print("Error: invalid command.")
        print("Variable chosen: "+thevar)
        varindex=self.FindVarIndex(thevar) #varindex: index of variable thevar
        oldvarval=self.vardicts[varindex]["equation"] #oldvarval: holds original var value to restore if export cancelled
        while True: #input number of notes to export
            print("Define number of notes to export (12 is an octave):")
            command=input()
            try:
                numberofnotes=int(command)
                if numberofnotes>0: break
            except:
                command
            print("Error: enter an integer greater than zero")
        while True: #Enter a starting pitch
            print("Choose starting note:")
            for a in range(1,13):
                print(str(a)+ ":\t"+notelist[a-1])
            command==input()
            try:
                startingnote=int(a-1)
            except:
                startingnote
            if (startingnote>-1) and (startingnote<12):
                break
            print("Error: enter an integer between 1 and 12.")
        while True:
            print("Choose starting octave")
            print(
                " 0: Infrasonic bass: 13.75-25.957\n",
                "1: Contrabass 27.5-51.913\n",
                "2: Bass: 55-103.826 Hz\n",
                "3: Baritone: 110-207.652\n",
                "4: Tenor: 220-415.305 Hz\n",
                "5: Contralto: 440-830.609 Hz\n",
                "6: Alto: 880-1661.219 Hz\n",
                "7: Mezzo Soprano: 1760-3322.438\n",
                "8: Soprano: 3520-6644.875\n",
                "9: Sopranissimo: 7040-13289.750 Hz\n",
                "10: Supersonic Soprano: 14080-26579.501 Hz")
            command=input()
            try:
                command=int(command)
                if (command>-1) and (command<12):
                    startingoctave=command
                    break
            except:
                continue
            print("Error: invalid command. Enter a value between 0 and 11.")
        startingfreq=13.75 * twelverttwo**float(startingnote) * 2.0**float(startingoctave)
        #startingfreq: first pitch to export. Lowest A, adjusted to note by 12rt2^half steps up,
        #adjusted to octave by 2^startingoctave
        for a in range(numberofnotes):
            currentnote=(startingnote+a)%12 #current note being exported
            currentoctave=startingoctave+(startingnote+a)//12 #currentoctave: current octave being exported
            newname=self.name+"_"+shortnotelist[currentnote]+str(currentoctave) #new export name. Ex: SoundName_Bf2
            
            self.vardicts[int(self.FindVarIndex(thevar))]["equation"]=startingfreq*twelverttwo**a #changes variable to current frequency
            print("Exporting note "+str(a)+" of "+ str(numberofnotes)+"...")
            self.FE.Go(self.wd,newname,self.exportbits,self.exporthz,self.exportpow, self.exportlen, self.vardicts, self.fundicts)

#(6)Save funcs
    def Save(self): #saves file
        print("Saving...")
        #creates folder structure for the save
        if os.path.isdir(self.wd + "//Saves")==False:
            os.mkdir(self.wd + "//Saves")
        if os.path.isfile(self.wd + "//Saves//" + self.name + ".fou"): 
            print("File already exists. Save will overwrite old file.")
            if self.YouSure()==False:
                return

        savedir=self.wd + "//" + "Saves" + "//" + self.name + ".fou" #savedir: full directory name of save file
        savefile=open(savedir, "w")
        for a in self.writelist: self.WriteHelperVars(savefile,a) #writelist defined in init, list of variables to be saved
        savefile.close()
        print("Project Saved as\n" + savedir)
        return
    def WriteHelperVars(self,file,var): #writes var and val to file
        file.write(var + "\n")
        if var=='self.vardicts':
            for a in self.vardicts:
                file.write(a["var"]+"\n")
                file.write(a["equation"]+"\n")
            file.write("\n")
        elif var=='self.fundicts':
            for a in self.fundicts:
                file.write(a["fun"]+"\n")
                for b in a["points"]:
                    file.write(str(b[0])+":"+b[1]+"\n")
        else:
            file.write(str(eval(var))+"\n\n")
            
#(7)Load funcs
    def LoadMenu(self): #Lists Projects to load
        #Handles save directory
        savedir=self.wd+"//Saves"
        if os.path.isdir(savedir)==False: #Looks for 'Saves' folder in directory
            #Makes a Saves folder if none found
            print("making a dir")
            os.mkdir(savedir)
        #Lists save files in 
        loadmenu=os.listdir(savedir)
        if len(loadmenu)==0:
            print("No files to load. Save something before you load something!")
        loadmenu.append("Go Back")

        #List load options from Saves directory
        while True:
            print("\nLoad Menu. Choose a file to load...")
            for i in range(len(loadmenu)):
                print(str(i+1)+":"+str(loadmenu[i]))
            command=input()

            #Check is command is in integer
            try:
                command=int(command)-1
                break
            except:
                print("Error, enter a number from the list.")
                command="I dunno"
                
        #Act if command is within range   
        if (command>=0) and (command <len(loadmenu)-1) :
            #Check is saving before loading
            while True:
                print("Loading file will overwite current project. Save before loading?")
                print("1:YES \n2:NO")
                yn=input()
                if yn=="1":
                    self.Save()
                    yn="2"
                if yn=="2":
                    self.Load(savedir+"/"+loadmenu[int(command)])
                    return
                print("Error, invalid command.")
        elif command==len(loadmenu)-1: #"Go back" command in load menu
            return
        print("Error, enter a number within range.")       
    def Load(self, directory): #Loads a project from a file directory
        #Loads raw data from file into loadlist
        print("Loading file "+directory+"...")
        if os.path.isfile(directory):
            #Loads the main instrument info
            loadfile=open(directory)
        else:
            print ("file \n" + directory + "\nnot found")
            return
        loadlist=loadfile.readlines()
        for x in range(len(loadlist)):
            loadlist[x]=loadlist[x].strip("\n")

        #Converts raw data from loadlines into project data.
        #First, some variables are initiated
        invardicts=False #Boolean, is invardicts being currently loaded?
        infundicts=False #Bool, is infundicts being currently loaded?
        self.ClearFunLists() #clears out point lists in fundicts to be reloaded
        
        for a in range(len(loadlist)-1):
            result=loadlist[a] #line being loaded
            if result in self.writelist: #introduction of new variable ends vardicts and fundict load protocols
                invardicts=False
                infundicts=False
            if result=="self.vardicts": #introduction of vardicts variable begins vardict load protocol
                invardicts=True
            if result=="self.fundicts": #introduction of fundicts variable begins fundict load protocol
                infundicts=True

            #Based on invadicts and infundicts, chooses variable load protocol.
            if invardicts==True:
                self.LoadVarDicts(loadlist[a],loadlist[a+1])
            elif infundicts==True:
                self.LoadFunDicts(loadlist[a],loadlist[a+1])
                b=2
                while (a+b<len(loadlist))and (self.FindFunIndex(loadlist[a+b])=="Not found"): #continue to add points to function pointlist until
                #another function name found in load file
                    self.LoadFunDicts(loadlist[a],loadlist[a+b])
                    b+=1
            else:
                self.LoadVar(loadlist[a],loadlist[a+1])

        print("File loaded.")   
    def LoadVar(self, var, val): #loads variable by name
        if var=="self.name": self.name=val
        elif var=="self.saveversion":
            if val!=self.version:
                print("Warning: version of save file and software do not match. Load file may be incompatible.")
                print("save ver: "+self.saveversion)
                print("software ver: "+self.version)
                print("Press Enter to continue.")
                input()
        elif var=="self.exportbits": self.exportbits=int(val)
        elif var=="self.exporthz": self.exporthz=int(val)
        elif var=="self.exportpow": self.exportpow=float(val)
        elif var=="self.exportlen": self.exportlen=float(val)
        elif var=="self.vardicts": return "self.vardicts" #indicates that self.vardicts is being loaded
        elif var=="self.fundicts": return "self.fundicts" #indicates that self.fundicts is being loaded
    def LoadVarDicts(self, var, val): #loads vardicts
        #var: letter of Vardict to load
        #val: value of vardict to load
        ind=self.FindVarIndex(var)
        if ind != "Not found":
            self.vardicts[ind]["equation"]=val
            if var=="J": return False
            return True
        return True
    def ClearFunLists(self): #clears point lists from fundicts
        for a in self.fundicts: a["points"]=[]
    def LoadFunDicts(self, var, val): #loads fundicts
        ind=self.FindFunIndex(var)
        print(ind)
        if ind != "Not found":
            val=val.split(":")
            val[0]=int(float(val[0]))
            print(val)
            self.fundicts[ind]["points"].append(val)
            return True
        return True

#(8)Debug funcs   
    def Debug(self): #lists all values
        print(('\nDefault Settings:'
               '\nself.defaultfx: '),self.defaultfx,
               '\nself.wd: ', self.wd,
               '\nself.version', self.version,
              
               '\nExport Settings:'
               '\nself.name: ',self.name,
               '\nself.saveversion: ',self.saveversion,
               '\nself.exportbits: ',self.exportbits,
               '\nself.exporthz: ',self.exporthz,
               '\nself.exportpow: ',self.exportpow,
               '\nself.exportlen: ',self.exportlen,
               '\n\nself.vardicts:',self.PrintVardicts(),
               '\nself.fundicts: ',self.PrintFundicts())
        input("Press Enter to Continue...")
    def PrintVardicts(self): #Prints vardicts neatly, helper for Debug
        printlines="\n"
        for x in self.vardicts: printlines=printlines+str(x["var"])+"="+str(x["equation"])+"\n"
        return printlines
    def PrintFundicts(self): #Prints fundicts neatly, helper for Debug
        printlines="\n"
        for x in range(len(self.fundicts)): #For each custom function...
            printlines = printlines + self.fundicts[x]["fun"] + ":\n"
            for y in range(len(self.fundicts[x]["points"])): #For each point in function
                printlines= printlines+"Point " + str(y+1) + ": Time=" + str(self.fundicts[x]["points"][y][0])+ ", Value: " + self.fundicts[x]["points"][y][1] + "\n"
        return printlines

#(9) Help func
    def Help(self): #opens guide
        os.system(self.wd+"\Help.pdf")

#(10)Exit Funcs
    def YouSure(self): #Quits program
        while True:
            print(('Are you sure?'
                   '\n1: Yes'
                   '\n2: No'))
            command=input()
            if (command=="1" or command.upper()=='Y' or command.upper()=="YES"): return True
            elif(command=="2" or command.upper()=='Y' or command.upper()=="NO"): return False
            else: print ("Error, invalid command.")

#class def ends, this command initiates a class instance
FM=FourierMenu()
